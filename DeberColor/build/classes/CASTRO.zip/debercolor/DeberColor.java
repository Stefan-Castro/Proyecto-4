package debercolor;

public class DeberColor {

    public static void main(String[] args) {
    Ventana v= new Ventana();    
    }    
}
